# TP II - Consultor de Séries (API TVMaze)

Sistema em Java (sem framework, no mesmo estilo do material da aula) que:

- Apresenta um **menu em loop** com as opções `Consultar`, `Listar` e `Sair`.
- Consome a **API pública TVMaze** (`https://api.tvmaze.com`), que não exige chave/token.
- Registra **toda entidade consultada** em um arquivo `consultas.log`, com data, hora e **fuso horário** (`America/Sao_Paulo`).
- Usa uma classe genérica `ConverteDados` para desserializar qualquer JSON em qualquer classe Java, em vez de instanciar `ObjectMapper` na classe principal.

## Estrutura de pacotes

```
br.com.fatec.tp2
├── Main.java              -> menu em loop (Consultar / Listar / Sair)
├── ConsultaSerieAPI.java  -> chamada HTTP à API TVMaze
├── ConverteDados.java     -> classe genérica de conversão JSON -> objeto (usa Jackson)
├── IConverteDados.java    -> contrato da classe acima
├── DadosSerie.java        -> entidade "Série" retornada pela API
├── DadosAvaliacao.java    -> sub-objeto "rating" do JSON
├── DadosRede.java         -> sub-objeto "network" do JSON
└── RegistradorLog.java    -> grava/lê o arquivo consultas.log
```

## Como executar

Pré-requisitos: **Java 17+** e **Maven** instalados.

```bash
# compilar e rodar direto
mvn compile exec:java

# ou gerar um .jar executável e rodar
mvn package
java -jar target/tp2-spring-java.jar
```

## Exemplo de uso

```
==========================================
 Bem-vindo ao Consultor de Séries (TVMaze)
==========================================
Escolha uma opção:
1. Consultar
2. Listar
3. Sair
> 1

Digite o nome da série que deseja consultar: Breaking Bad
---------------------------------------------
Nome.........: Breaking Bad
Tipo.........: Scripted
...
---------------------------------------------
```

O arquivo `consultas.log` é criado automaticamente na primeira consulta, na
mesma pasta em que o programa é executado.

## Trocando a entidade consultada

Se quiser usar outra API/entidade, basta:
1. Trocar a URL em `ConsultaSerieAPI`.
2. Criar uma nova classe de dados (como `DadosSerie`) com os campos do novo JSON.
3. Chamar `converteDados.obterDados(json, NovaClasse.class)` no `Main` — a classe
   `ConverteDados` já é genérica e funciona para qualquer entidade.
